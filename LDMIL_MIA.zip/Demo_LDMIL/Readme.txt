

[Data] 
Please use the theano matrix format and tensorflow backend.


[Train and Test]
  1)Train the model:
        python main.py --mode train


  2) Test the model:
        python main.py --mode test
  

[References]

If you use our code, please cite the references [1-2] for landmark discovery and reference [3] for landmark-based multi-instance learning.

[1] Jun Zhang, Yue Gao, Yaozong Gao, Munsell Brent, and Dinggang Shen. Detecting Anatomical Landmarks for Fast Alzheimer’s Disease Diagnosis. IEEE Trans. on Medical Imaging, 35(12):2524-2533, 2016.

[2] Jun Zhang, Mingxia Liu, Le An, Yaozong Gao, Dinggang Shen. Alzheimer’s Disease Diagnosis using Landmark-based Features from Longitudinal Structural MR Images. IEEE Journal of Biomedical and Health Informatics, DOI: 10.1109/JBHI.2017.2704614, 2017.

[3] Mingxia Liu, Jun Zhang, Ehsan Adeli, Dinggang Shen. Landmark-based Deep Multi-Instance Learning for Brain Disease Diagnosis. Medical Image Analysis, 43, 157-168, 2018.

                                                    