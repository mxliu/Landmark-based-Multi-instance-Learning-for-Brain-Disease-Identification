
"""
Please use the theano matrix format and tensorflow backend.

change the file  $HOME/.keras/keras.json to

{
    "image_data_format": "channels_first",
    "epsilon": 1e-07,
    "floatx": "float32",
    "backend": "tensorflow"
}

Train the model:
python main.py --mode train


Test the model:
python main.py --mode test


If you use our code, please cite the references [1] and [2] for landmark discovery and reference [3] for landmark-based multi-instance learning.
[1] Jun Zhang, Yue Gao, Yaozong Gao, Munsell Brent, and Dinggang Shen. 
    Detecting Anatomical Landmarks for Fast Alzheimers Disease Diagnosis. 
    IEEE Trans. on Medical Imaging, 35(12): 2524-2533, 2016.
[2] Jun Zhang, Mingxia Liu, Le An, Yaozong Gao, Dinggang Shen. 
    Alzheimers Disease Diagnosis using Landmark-based Features from Longitudinal Structural MR Images. 
    IEEE Journal of Biomedical and Health Informatics, DOI: 10.1109/JBHI.2017.2704614, 2017.
[3] Mingxia Liu, Jun Zhang, Ehsan Adeli, Dinggang Shen. 
    Landmark-based Deep Multi-Instance Learning for Brain Disease Diagnosis. 
    Medical Image Analysis, 43: 157-168, 2018.

Authors: Dr. Mingxia Liu and Dr. Jun Zhang   
"""


from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution3D, MaxPooling3D, Merge 
from keras.optimizers import SGD, RMSprop, Adadelta
import numpy as np
import scipy.io as sio
import argparse
parser = argparse.ArgumentParser(description='Landmark-based multi-instance learning for AD diagnosis')
parser.add_argument('--mode', type=str, default='train', required=True, help='train or test')
opt = parser.parse_args()
print(opt)



def single_instance(patchsize):
    model = Sequential()
    model.add(Convolution3D(16, 3, 3, 3, border_mode='valid', input_shape=(1, patchsize, patchsize, patchsize)))
    model.add(Activation('relu'))
    model.add(Convolution3D(16, 3, 3, 3, border_mode='valid'))
    model.add(Activation('relu'))
    model.add(MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(Convolution3D(32, 2, 2, 2, border_mode='valid'))
    model.add(Activation('relu'))
    model.add(Convolution3D(32, 2, 2, 2, border_mode='valid'))
    model.add(Activation('relu'))
    model.add(MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(Convolution3D(32, 2, 2, 2, border_mode='valid'))
    model.add(Activation('relu'))
    model.add(Convolution3D(32, 2, 2, 2, border_mode='valid'))
    model.add(Activation('relu'))
    model.add(MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(Flatten())
    model.add(Dense(32, init='uniform',activation='relu'))
    model.add(Dropout(0.3))
    model.add(Dense(4, init='uniform', activation='relu'))

    return model

def merged_model(patchsize,landmk_num):
    branch = []
    for i_num in range(0,landmk_num):
        branch.append(single_instance(patchsize))
    
    merge_model = Sequential()
    merge_model.add(Merge(branch, mode='concat'))
    merge_model.add(Dropout(0.3))
    merge_model.add(Dense(4*landmk_num,activation='relu',name='FC1'))
    merge_model.add(Dropout(0.3))
    merge_model.add(Dense(1*landmk_num,activation='relu',name='FC2'))
    merge_model.add(Dropout(0.25))
    merge_model.add(Dense(2, init='uniform', activation='softmax'))

    sgd = SGD(lr=0.001, decay=1e-6, momentum=0.9, nesterov=True)
    merge_model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
    
    return merge_model


def MultiInstance_patch(images, labels, landmarks, patch_size, step_size, batch_size):
    landmarks = np.round(landmarks)
    landmk_num = np.size(landmarks,2)
    patches = np.zeros((batch_size,landmk_num,patch_size,patch_size,patch_size),dtype='uint8')
    var_range = range(-step_size,step_size+1,1)
    label = np.zeros((batch_size,2),dtype='uint8')
    while True:        
        i_sample = 0
        new_index = np.random.permutation(np.size(images,0))
        for i_subject_0 in range(np.size(images,0)):
            
            i_subject=new_index[i_subject_0]
            
            for i_landmk in range(0,landmk_num):
                i_x = np.random.permutation(var_range)[0] + landmarks[i_subject, 0, i_landmk]
                i_y = np.random.permutation(var_range)[0] + landmarks[i_subject, 1, i_landmk]
                i_z = np.random.permutation(var_range)[0] + landmarks[i_subject, 2, i_landmk]
                patches[i_sample,i_landmk,0:patch_size,0:patch_size,0:patch_size] = images[i_subject,int(i_x-np.floor(patch_size/2)):int(i_x+int(np.ceil(patch_size/2.0))),
                                                                                           int(i_y-np.floor(patch_size/2)):int(i_y+int(np.ceil(patch_size/2.0))),
                                                                                           int(i_z-np.floor(patch_size/2)):int(i_z+int(np.ceil(patch_size/2.0)))]
                                                                                           
                label[i_sample,:] = labels[i_subject,:]
            
            i_sample +=1
            
            if i_sample==batch_size:
                i_sample = 0
                mi_data = []
                for j_landmk in range(0,landmk_num):
                    
                    mi_data.append(patches[:,j_landmk:j_landmk+1,:,:,:])
                
                yield (mi_data, label)
                
def MultiInstance_patch_predict(images, landmarks, patch_size, batch_size):
    landmarks = np.round(landmarks)
    landmk_num = np.size(landmarks,2)
    patches = np.zeros((batch_size,landmk_num,patch_size,patch_size,patch_size),dtype='uint8')

    while True:
        
        
        
        
        
        i_sample = 0
        
        for i_subject in range(np.size(images,0)):

            
            for i_landmk in range(0,landmk_num):
                
                i_x = np.random.permutation(1)[0] + landmarks[i_subject, 0, i_landmk]
                i_y = np.random.permutation(1)[0] + landmarks[i_subject, 1, i_landmk]
                i_z = np.random.permutation(1)[0] + landmarks[i_subject, 2, i_landmk]
                patches[i_sample,i_landmk,0:patch_size,0:patch_size,0:patch_size] = images[i_subject,int(i_x-np.floor(patch_size/2)):int(i_x+int(np.ceil(patch_size/2.0))),
                                                                                           int(i_y-np.floor(patch_size/2)):int(i_y+int(np.ceil(patch_size/2.0))),
                                                                                           int(i_z-np.floor(patch_size/2)):int(i_z+int(np.ceil(patch_size/2.0)))]
                                                                                           
                
            
            i_sample +=1
            
            if i_sample==batch_size:
                i_sample = 0
                mi_data = []
                for j_landmk in range(0,landmk_num):
                    
                    mi_data.append(patches[:,j_landmk:j_landmk+1,:,:,:])
                
                return mi_data
                
patch_size = 24
landmk_num =20               
       

datapath = '/shenlab/lab_stor5/mingxiaLiu/LandmarkBasedMultiinstanceLearning/'


def train():

    data_train=sio.loadmat(datapath+'ADNI_Train.mat')
    images = np.array(data_train["data_image"])
    
    landmk_train=sio.loadmat(datapath+'Landmark_Train.mat')
    landmarks = np.array(landmk_train["crop_landmark_ADNI1_ADNC"])
    
    
    new_label2= np.zeros((np.size(images,0),2),dtype='uint8')
    
    new_label2[0:229,1]=1
    new_label2[229:428,0]=1
    #np.random.seed(10)
    new_index = np.random.permutation(np.size(images,0))

    
    
    new_landmark =landmarks[:,:,0:landmk_num]
    step_size = 5
    batch_size =16 


    
    
    sample_number = 350
    
    patch_data = MultiInstance_patch(images[new_index[0:sample_number],...], new_label2[new_index[0:sample_number],...], new_landmark[new_index[0:sample_number],...], patch_size, step_size, batch_size)
    patch_data_test = MultiInstance_patch(images[new_index[sample_number:428],...], new_label2[new_index[sample_number:428],...], new_landmark[new_index[sample_number:428],...], patch_size, 0, batch_size)
    
    M = merged_model(patch_size,landmk_num)
    
    import keras
    checkpoint = keras.callbacks.ModelCheckpoint(filepath='DiagnosisModel{0}'.format(landmk_num) ,save_best_only=True, mode='auto')
    M.fit_generator(generator=patch_data, validation_data=patch_data_test,samples_per_epoch=sample_number*1, nb_val_samples=428-sample_number,nb_epoch=40,callbacks=[checkpoint])

def test():
    data_train=sio.loadmat(datapath+'ADNI_Test.mat')
    images_test = np.array(data_train["data_image"])
    
    landmk_train=sio.loadmat(datapath+'Landmark_Test.mat')
    landmarks_test = np.array(landmk_train["crop_landmark_ADNI2_ADNC"])
    
    
    test_label= np.zeros((np.size(images_test,0),2),dtype='uint8')
    
    test_label[0:201,1]=1
    test_label[201:360,0]=1
    new_landmark_test =landmarks_test[:,:,0:landmk_num]
    subject_num = np.size(images_test,0)
    patch_data_test = MultiInstance_patch_predict(images_test, new_landmark_test, patch_size, subject_num)



    M = merged_model(patch_size,landmk_num)
    M.load_weights('DiagnosisModel{0}'.format(landmk_num))



    targets =M.predict(patch_data_test,batch_size=1)
    

    targets0 = targets[:,0]

    N_num = 200.0
    P_num = 159.0


    targets0[targets0<0.5] = 0
    targets0[targets0>=0.5] = 1
    
    
    
    TN = targets0+test_label[:,0]
    TN_num = float(len(np.argwhere(TN==0)))
    

    
    TP_num = float(len(np.argwhere(TN==2)))
    
    
    SPE = TN_num/N_num
    SEN = TP_num/P_num
    ACC = (TN_num+TP_num)/(N_num+P_num)
    
    
    print 'ACC', ACC, 'SEN', SEN, 'SPE', SPE
    
    
    
    
if opt.mode == 'train':
    train()
else:
     test()    
